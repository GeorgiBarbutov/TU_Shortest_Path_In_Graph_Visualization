﻿namespace TU_Shortest_Path_In_Graph_Vizualisation.Models.Contracts
{
    public interface IPoint
    {
        float X { get; }
        float Y { get; }
    }
}
